/*	$NetBSD: float.h,v 1.12 2003/02/26 21:29:00 fvdl Exp $	*/

#include <x86/float.h>
