/*	$NetBSD: ieeefp.h,v 1.3 2003/02/26 21:29:01 fvdl Exp $	*/

#include <x86/ieeefp.h>
