/*	$NetBSD: intrdefs.h,v 1.4 2011/08/10 06:30:59 cherry Exp $	*/

#include <x86/intrdefs.h>
#ifdef XEN
#include <xen/intrdefs.h>
#endif /* XEN */
