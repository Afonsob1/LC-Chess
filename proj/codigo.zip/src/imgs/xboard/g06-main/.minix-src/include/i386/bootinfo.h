/*	$NetBSD: bootinfo.h,v 1.14 2003/02/26 21:28:59 fvdl Exp $	*/

#include <x86/bootinfo.h>
