#ifndef DDEKIT_MINIX_PCI
#define DDEKIT_MINIX_PCI
void ddekit_pci_init_only_one(int skip);
#endif
