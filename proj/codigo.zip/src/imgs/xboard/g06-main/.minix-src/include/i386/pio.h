/*	$NetBSD: pio.h,v 1.20 2003/02/26 21:29:02 fvdl Exp $	*/

#include <x86/pio.h>
