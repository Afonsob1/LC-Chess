#pragma once

#define COLOR_TRANSPARENT 0xFF



