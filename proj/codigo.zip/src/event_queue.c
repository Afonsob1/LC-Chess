

#include "event_queue.h"

void initEventQueue(EventQueue * queue){

}
